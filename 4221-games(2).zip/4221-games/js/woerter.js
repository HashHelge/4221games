// Wortpaare: [Wort für Zivilisten, ähnliches Wort für den Imposter]
// Einfach erweitern – neue Kategorie = neuer Eintrag.
export const KATEGORIEN = {
  "Essen & Trinken": [
    ["Pizza", "Flammkuchen"], ["Sushi", "Ramen"], ["Döner", "Burger"], ["Spaghetti", "Risotto"],
    ["Croissant", "Brezel"], ["Pommes", "Kroketten"], ["Kaffee", "Tee"], ["Bier", "Wein"],
    ["Schokolade", "Gummibärchen"], ["Erdbeere", "Himbeere"], ["Raclette", "Fondue"],
    ["Pfannkuchen", "Waffeln"], ["Currywurst", "Bratwurst"], ["Eis", "Sorbet"], ["Lasagne", "Auflauf"]
  ],
  "Tiere": [
    ["Hund", "Wolf"], ["Katze", "Luchs"], ["Pinguin", "Möwe"], ["Elefant", "Nashorn"],
    ["Delfin", "Hai"], ["Adler", "Falke"], ["Biene", "Wespe"], ["Pferd", "Esel"],
    ["Frosch", "Kröte"], ["Eule", "Fledermaus"], ["Krokodil", "Eidechse"], ["Giraffe", "Zebra"],
    ["Hamster", "Meerschweinchen"], ["Löwe", "Tiger"]
  ],
  "Orte": [
    ["Strand", "Freibad"], ["Flughafen", "Bahnhof"], ["Kino", "Theater"], ["Krankenhaus", "Apotheke"],
    ["Bibliothek", "Buchladen"], ["Supermarkt", "Wochenmarkt"], ["Zoo", "Bauernhof"],
    ["Fitnessstudio", "Sporthalle"], ["Kirche", "Museum"], ["Restaurant", "Kantine"],
    ["Hotel", "Campingplatz"], ["Schule", "Universität"], ["Friseur", "Nagelstudio"]
  ],
  "Büro & Arbeit": [
    ["Meeting", "Workshop"], ["Kaffeemaschine", "Wasserspender"], ["Drucker", "Scanner"],
    ["Excel", "PowerPoint"], ["Homeoffice", "Großraumbüro"], ["Gehaltserhöhung", "Bonus"],
    ["Chef", "Teamleiter"], ["Mittagspause", "Feierabend"], ["Laptop", "Tablet"],
    ["Betriebsausflug", "Weihnachtsfeier"], ["Deadline", "Meilenstein"], ["Teams", "Zoom"],
    ["Post-it", "Notizblock"], ["Praktikant", "Azubi"], ["Urlaubsantrag", "Krankmeldung"]
  ],
  "Berufe": [
    ["Arzt", "Krankenpfleger"], ["Pilot", "Flugbegleiter"], ["Koch", "Bäcker"],
    ["Polizist", "Feuerwehrmann"], ["Lehrer", "Erzieher"], ["Anwalt", "Richter"],
    ["Architekt", "Bauingenieur"], ["Zahnarzt", "Tierarzt"], ["Journalist", "Fotograf"],
    ["Gärtner", "Förster"], ["Mechaniker", "Elektriker"], ["Friseur", "Maskenbildner"]
  ],
  "Sport": [
    ["Fußball", "Handball"], ["Tennis", "Badminton"], ["Skifahren", "Snowboarden"],
    ["Schwimmen", "Tauchen"], ["Basketball", "Volleyball"], ["Golf", "Minigolf"],
    ["Boxen", "Ringen"], ["Joggen", "Wandern"], ["Yoga", "Pilates"],
    ["Radfahren", "Mountainbiken"], ["Bowling", "Kegeln"], ["Darts", "Billard"]
  ],
  "Gegenstände": [
    ["Regenschirm", "Sonnenschirm"], ["Brille", "Kontaktlinsen"], ["Gabel", "Löffel"],
    ["Kerze", "Taschenlampe"], ["Uhr", "Wecker"], ["Schlüssel", "Schloss"], ["Kissen", "Decke"],
    ["Spiegel", "Fenster"], ["Rucksack", "Koffer"], ["Schere", "Messer"],
    ["Zahnbürste", "Kamm"], ["Handy", "Fernbedienung"]
  ],
  "Urlaub & Reisen": [
    ["Kreuzfahrt", "Segeltörn"], ["Camping", "Hostel"], ["Paris", "Rom"],
    ["Strandurlaub", "Skiurlaub"], ["Reisepass", "Personalausweis"], ["Sonnencreme", "After-Sun"],
    ["Mallorca", "Ibiza"], ["Wohnmobil", "Wohnwagen"], ["Zelt", "Hängematte"],
    ["Souvenir", "Postkarte"], ["Jetlag", "Seekrankheit"], ["Safari", "Dschungeltour"]
  ],
  "Freizeit & Feste": [
    ["Geburtstag", "Hochzeit"], ["Grillabend", "Picknick"], ["Karaoke", "Disco"],
    ["Brettspiel", "Kartenspiel"], ["Weihnachten", "Silvester"], ["Halloween", "Karneval"],
    ["Konzert", "Festival"], ["Umzug", "Renovierung"], ["Escape Room", "Lasertag"],
    ["Flohmarkt", "Weihnachtsmarkt"], ["Kinoabend", "Spieleabend"]
  ]
};
