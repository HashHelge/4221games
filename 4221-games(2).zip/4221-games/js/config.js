// ─────────────────────────────────────────────────────────────
//  Supabase-Zugangsdaten für die Online-Funktionen.
//  Der publishable Key ist öffentlich und darf hier stehen.
// ─────────────────────────────────────────────────────────────
export const SUPABASE_URL = "https://hspjsvveamsocxarqsvp.supabase.co";
export const SUPABASE_KEY = "sb_publishable_UrimqRjl_gZB6pKh5y7jKg_8quffxSX";
